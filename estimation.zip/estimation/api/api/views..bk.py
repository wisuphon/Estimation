import logging
import json

from confluent_kafka import Producer
from rest_framework.views import APIView
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication

logger = logging.getLogger(__name__)

oProducer = Producer({'bootstrap.servers': 'localhost:9092'})

def delivery_report(err, msg):
    if err is not None:
        logger.error(err)
    else:
        print(f'Message delivered to {msg.topic()} [{msg.partition()}]')

def send_notification(topic, payload):
    oProducer.produce(topic, payload.encode('utf-8'), callback=delivery_report)
    oProducer.poll(0)
    print(f'Message sent to {topic}: {payload}')


class Home(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]   

    def post(self, request):        
        oData = request.data        
        if 'ptImg' not in oData or not oData.get('ptImg'):
            return Response({
                "rtCode": "400",
                "rtDesc": "Invalid ptImg",
                }, status=status.HTTP_400_BAD_REQUEST)        
        elif(oData.get('ptImg') == ""):
            return Response({
                "rtCode": "400",
                "rtDesc": "ptImg should not be empty",
            }, status=status.HTTP_400_BAD_REQUEST)
        try:
            aData = {
                "rtApp":  oData.get('ptApp'),            
                "rtBch":  oData.get('ptBch'),
                "ptImg":  oData.get('ptImg')               
            }
            # send
            send_notification('topic', json.dumps(aData))
            oProducer.flush()
            
            
            
            # get
            
            
            
            
            
            
            return Response(aData, status=status.HTTP_200_OK)            
        except(Exception) as oError:
            logger.error(oError)
            return Response({
                "rtCode": "500",
                "rtDesc": "Internal server error",
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)