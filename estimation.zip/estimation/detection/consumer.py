import base64
import json
import cv2
import logging
import insightface
import sys
import time
import base64
import time
import numpy as np

from time import strftime
from datetime import datetime
from insightface.app import FaceAnalysis
from logging.handlers import RotatingFileHandler
from confluent_kafka import Consumer, KafkaError

oConsumer = Consumer({
    'bootstrap.servers': 'localhost:9092',
    'group.id': 'notification-group',
    'auto.offset.reset': 'earliest'
})

oConsumer.subscribe(['topic'])

nID = 0
app = FaceAnalysis(name='buffalo_l', providers=['CPUExecutionProvider'])
# app = FaceAnalysis(providers=['CUDAExecutionProvider'])
app.prepare(ctx_id=nID)

def FMxMain(oGetJson):
    aoGetData = json.loads(oGetJson.decode('utf-8'))    
    ptApp = aoGetData['ptApp']
    ptBch = aoGetData['ptBch']
    ptImg = aoGetData['ptImg']
    oImageOriginal = base64.b64decode(ptImg)
    oImageNumpy = np.frombuffer(oImageOriginal, dtype=np.uint8)
    oImage = cv2.imdecode(oImageNumpy, flags=1) 
     
    # img = cv2.imread(img_path)

    # ตรวจจับและวิเคราะห์ใบหน้าในภาพ
    faces = app.get(oImage)
    for face in faces:
        # ดึงข้อมูลอายุและเพศ
        tAge = face.age
        tGender = 'Man' if face.gender == 1 else 'Woman'
        aData = {
                "rtApp":  ptApp,            
                "rtBch":  ptBch,
                "raoFacInfo":  [{
                    "rtAge": tAge,
                    "rtGender": tGender,
                }],
                "rtCode": "200",
                "rtDesc": "Success"
        }        
        print("Age: ",tAge)
        print("Gender: ",aData)
        
        
        # send
        
# start   
if __name__ == '__main__':
    print(' [*] Waiting for messages. To exit press CTRL+C')
    #Logs
    handler = RotatingFileHandler('/logs/'+datetime.now().strftime('%Y-%m-%d')+'.log', maxBytes=1048576000, backupCount=3)
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.ERROR)
    logger.setLevel(logging.INFO)
    logger.addHandler(handler)        
    try:
        while True:
            msg = oConsumer.poll(1.0)
            if msg is None:
                continue
            if msg.error():
                if msg.error().code() == KafkaError._PARTITION_EOF:
                    continue
                else:
                    logger.info("Error: "+str(datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3])+" " + str(msg.error()))
                    break
            FMxMain(msg.value())
            print(f'Received message from topic {msg.topic()}: {msg.value().decode("utf-8")}')

    except KeyboardInterrupt:
        pass

    finally:
        oConsumer.close()