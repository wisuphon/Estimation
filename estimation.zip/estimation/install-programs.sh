#!/bin/bash

# chmod +x install-programs.sh
# ./install-programs.sh

# อัพเดทแพคเกจ
sudo apt update && sudo apt upgrade -y


# ติดตั้ง Python 3 และ pip
sudo apt install -y python3 python3-pip

# ติดตั้งโปรแกรมเพิ่มเติมที่ต้องการ
# sudo apt install -y <other-programs>

# ทำความสะอาดแพคเกจที่ไม่จำเป็น
sudo apt autoremove -y




pip3 install package_name