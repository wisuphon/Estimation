from django.urls import path
from .views import Home


urlpatterns = [
    path('api/estimations/face/', Home.as_view()),
]