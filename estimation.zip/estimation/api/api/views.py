import logging
import json


import base64
import json
import cv2
import logging
import insightface
import sys
import time
import base64
import time
import numpy as np

from time import strftime
import datetime
from insightface.app import FaceAnalysis
from deepface import DeepFace

from rest_framework.views import APIView
from rest_framework import status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication

logger = logging.getLogger(__name__)

typeEmotion = {	"happy": "happy",
		"surprise": "happy",
		"neutral": "neutral",
		"angry": "notimpressed",
		"disgust": "notimpressed",
		"fear": "notimpressed",
		"sad": "notimpressed"
}

tAge_map = {18: "<18", 30: "19-30", 40: "31-40", 50: "41-50"}

# app = FaceAnalysis(name='buffalo_l', providers=['CPUExecutionProvider'])
app = FaceAnalysis(providers=['CUDAExecutionProvider'])
app.prepare(ctx_id=0) # -1 CPU, 0 GPU 

class Home(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    def post(self, request):        
        tTimeStart = datetime.datetime.now()
        oData = request.data        
        if 'ptImg' not in oData or not oData.get('ptImg'):
            return Response({
                "rtCode": "400",
                "rtDesc": "Invalid ptImg",
                }, status=status.HTTP_400_BAD_REQUEST)        
        elif(oData.get('ptImg') == ""):
            return Response({
                "rtCode": "400",
                "rtDesc": "ptImg should not be empty",
            }, status=status.HTTP_400_BAD_REQUEST)
        try:             
            oImageOriginal = base64.b64decode(oData.get('ptImg'))
            oImageNumpy = np.frombuffer(oImageOriginal, dtype=np.uint8)
            oImage = cv2.imdecode(oImageNumpy, flags=1) 
            
            # img = cv2.imread(img_path)
            
            # ตรวจจับและวิเคราะห์ใบหน้าในภาพ
            result = DeepFace.analyze(oImage, actions=['age', 'gender', 'emotion'])
            faces = app.get(oImage)
            emotion = result[0]['dominant_emotion']
            del oImage
            for face in faces:
                # ดึงข้อมูลอายุและเพศ
                tAge = face.age
                tGender = 'Male' if face.gender == 1 else 'Female'
                # tAge = result[0]['age']
                # tGender = result[0]['dominant_gender']
                # tGender = 'Male' if tGender == "Man" else 'Female'
                tRangAge = next((v for k, v in tAge_map.items() if tAge <= k), "50+")
                aData = {
                        "rtApp":  oData.get('ptApp'),            
                        "rtBch":  oData.get('ptBch'),
                        "raoFacInfo":  [{
                            "rtAge": tRangAge,
                            "rtAgeRang": tRangAge,
                            "rtGender": tGender,
                            "rtEmotion": typeEmotion[emotion],
                            "rtTimestart": tTimeStart,
                            "rtTimeEnd": datetime.datetime.now(),
                        }],
                        "rtCode": "200",
                        "rtDesc": "Success"
                }
                return Response(aData, status=status.HTTP_200_OK)            
        except(Exception) as oError:
            # logger.error(oError)
            return Response({
                "rtCode": "500",
                "rtDesc": "Internal server error",
            }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
